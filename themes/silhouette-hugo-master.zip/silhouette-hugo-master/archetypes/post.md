---
title: "{{ replace .Name "-" " " | title }}"
date: {{ .Date }}
draft: true
categories:
  - Software Development
tags:
  - Untagged
---

**Insert Lead paragraph here.**