## [Machine learning学习笔记](https://zhaohuabing.com/machine-learning) 

Coursera 在线课程 [Machine learning]( https://www.coursera.org/learn/machine-learning) 笔记<BR>
讲师: 吴恩达(Andrew Ng) <BR>
课程地址：https://www.coursera.org/learn/machine-learning<BR>
